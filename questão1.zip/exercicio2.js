var numero1 = 4
console.log(numero1);

var numero2 = 7
console.log(numero2);

var numero3 = 9
console.log(numero3);

var numero4 = 11 
console.log(numero4);

var numero5 = 5
console.log(numero5);