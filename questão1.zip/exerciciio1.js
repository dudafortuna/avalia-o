let aluno1 = "Maria Eduarda"
let aluno2 = "Alana"
let aluno3 = "Heloisa Rodolfo"
let aluno4 = "Gabriel Zanela"
let aluno5 = "Carine Amiratti"




console.log(aluno1)
console.log(aluno2)
console.log(aluno3)
console.log(aluno4)
console.log(aluno5)



