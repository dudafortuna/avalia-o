var salario1 = 500
console.log(salario1)

var salario2 = 1000
console.log(salario2)

var salario3 = 1500
console.log(salario3)

var salario4 = 2000
console.log(salario4)

var salario5 = 2500 
console.log(salario5)