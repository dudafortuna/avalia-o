const isVerdadeiro = true
console.log(isVerdadeiro)

const isOline = false
console.log(isOline)


const isAtivo = true 
console.log(isAtivo)

let nome1 = "planta"
let nome2 = "mesa"
let nome3 = "colher"
let nome4 = "flor"
console.log(nome1.length + nome2.length + nome3.length + nome4.length)