var isOline = false
console.log(isOline)

var isAtivo = true
console.log(isAtivo)

var isaprovado = false
console.log(isaprovado)

var isVerdadeiro = true 
console.log(isVerdadeiro)

var isNegativo = false
console.log(isNegativo)